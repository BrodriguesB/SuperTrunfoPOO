package Class;

public class Jogador {
	
	int Quantidade_Cartas;
	
	public void pegar_carta() {
		
		
	}
	
	public void escolher_atributo() {

	
	}
	
	public void jogar_carta() {

	
	}
	
	public void conta_carta() {
		
		
	}
}
