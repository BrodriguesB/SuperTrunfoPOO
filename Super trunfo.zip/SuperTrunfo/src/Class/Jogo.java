package Class;

public abstract class Jogo {
	
	int Conta_Cartas;
	
	public void gerador_cartas() {
		
	}
	
	public void distribuir_cartas() {
		
		
	}
	
	public void compara_cartas() {
		
		
	}
	
	public void recolhe_cartas() {

		
	}

}
