package Class;

public class Carta {
	
	int	atribute1; 
	int	atribute2; 
	int	atribute3; 
	int	atribute4; 
	int	atribute5; 
	String NomePersonagem;
	boolean SuperTrunfo;
	String Grupo;
}
